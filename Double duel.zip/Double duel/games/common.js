const countDown=()=>{
  let time=3;
  let countDownCont=document.createElement("div");
  document.body.appendChild(countDownCont);
    countDownCont.classList.add("timer");
    countDownCont.innerHTML=time;
  setTimeout(()=>{
    time--;
    countDownCont.innerHTML=time;
    setTimeout(()=>{
      time--;
      countDownCont.innerHTML=time;
      setTimeout(()=>{
        time--;
        countDownCont.innerHTML="GO";
        setTimeout(()=>{
          document.body.removeChild(countDownCont);
          removeCover();
        },500);
      },1000);
    },1000);
  },1000);
}

const cover=()=>{
  let cover=document.createElement("div");
  cover.classList.add("cover");
  document.body.appendChild(cover);
}

cover();
countDown();

const removeCover=()=>{
  document.body.removeChild(document.querySelector(".cover"));
}

const gameOverScreen=(result)=>{
  cover();
  let screen=document.createElement("div");
  screen.classList.add("screen");
  screen.innerHTML=`<img src='${result=="red"?"../../assets/victory-red.png":result=="blue"?"../../assets/victory-blue.png":"../../assets/draw.png"}'>`;
  console.log(screen.innerHTML);
  setTimeout(()=>{
    removeCover();
    document.body.appendChild(screen);
    screen.style.opacity="1";
    setTimeout(()=>{
      location.href="../../index.html";
    },1500);
  },500);
}

const renderScoreBoard=(red,blue)=>{
  document.querySelector("main").removeChild(document.querySelector(".score"));
  let scoreCont=document.createElement("div");
  scoreCont.classList.add("score");
  scoreCont.innerHTML=`<span class="red">${red}</span>
      <span class="dash">-</span>
      <span class="blue">${blue}</span>`;
  document.querySelector("main").appendChild(scoreCont);
}

