window.onload=()=>{
  document.querySelectorAll(".card-place-holder").forEach((element,index)=>{
    element.id="c-"+index;
  });
  turn=randomNumber(1,2) === 1?"red":"blue";
  randomizeCards();
  createCards();
  
  if(turn==="blue"){
    document.body.style.background="#8fe9e9";
  }else{
    document.body.style.background="#f0a3a3";
  }
  
  renderScoreBoard(scores.red,scores.blue);
}

let cards=[
  {path:"../../assets/dhamaal.jpg"},
  {path:"../../assets/dhamaal.jpg"},
  {path:"../../assets/housefull3.jpg"},
  {path:"../../assets/housefull3.jpg"},
  {path:"../../assets/jaiho.jpg"},
  {path:"../../assets/jaiho.jpg"},
  {path:"../../assets/rrr.jpg"},
  {path:"../../assets/rrr.jpg"},
  {path:"../../assets/pk.jpg"},
  {path:"../../assets/pk.jpg"},
  {path:"../../assets/houseful4.jpg"},
  {path:"../../assets/houseful4.jpg"},
  {path:"../../assets/dreamgirl.jpg"},
  {path:"../../assets/dreamgirl.jpg"},
  {path:"../../assets/three-ideots.jpg"},
  {path:"../../assets/three-ideots.jpg"},
 ]
let turn;
let randomizedCards=[];
let currentCards=[];
let scores={red:0,blue:0}

const randomNumber=(min,max)=>{
  return Math.floor(Math.random()*max+min);
}

const findRandomElement=(arr)=>{
  let rand=randomNumber(0,arr.length-1);
  return {
    element:arr[rand],
    index:rand
  }
}

const randomizeCards=()=>{
  while(cards.length>0){
    let rand=findRandomElement(cards);
    let element=rand.element;
    let index=rand.index;
    randomizedCards.push(element);
    cards.splice(index,1);
  }
}

const createCards=()=>{
  randomizedCards.forEach((card,index)=>{
    document.getElementById("c-"+index.toString()).innerHTML+=`<div class="memory-card container" onclick="flipCard(this)">
      <div class="card flip">
          <div class="front" ></div>
          <div class="back" style="background-image:url(${card.path});">
        </div>
      </div>
    </div>`;
  });
}

const flipCard=(element)=>{
  if(!element.childNodes[1].classList.contains("flip")){
    return;
  }
  
  if(currentCards.length<2){
    
    element.childNodes[1].classList.remove("flip");
    currentCards.push(element);
    
  }
  
   
   if(currentCards.length===2){
    let card1Image=currentCards[0].childNodes[1].childNodes[3].style.backgroundImage;
    
    let card2Image=currentCards[1].childNodes[1].childNodes[3].style.backgroundImage;
    cover();
    document.querySelector(".cover").style.background="transparent";
    setTimeout(()=>{
      removeCover();
      if(card1Image===card2Image){
      scores[turn]++;
      renderScoreBoard(scores.red,scores.blue);
      if(scores.red+scores.blue===8){
        if(scores.red===scores.blue){
          gameOverScreen("draw");
        }else if(scores.red>scores.blue){
          gameOverScreen("red");
        }else{
          gameOverScreen("blue");
        }
      }
      
     }else{
       
       currentCards[0].childNodes[1].classList.add("flip");
       currentCards[1].childNodes[1].classList.add("flip");
       toggleTurn();
     }
     currentCards=[];
    },1500);
  }
}

let toggleTurn=()=>{
  turn=turn==="red"?"blue":"red";
  if(turn==="blue"){
    document.body.style.background="#8fe9e9";
  }else{
    document.body.style.background="#f0a3a3";
  }
}

