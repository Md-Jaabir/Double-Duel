let playerTop=parseFloat(getComputedStyle(document.querySelector(".players")).getPropertyValue("top"));
let player=document.querySelector(".players");
console.log(playerTop);
let advantage={
  red:0,
  blue:0
}

let scores={
  red:0,
  blue:0
}

const render=()=>{
  
  if(advantage.red){
  document.querySelector(".players").style.top=`${40.5+advantage.red*18.5}px`;
  }
  
  if(advantage.blue){
  document.querySelector(".players").style.top=`${40.5-advantage.blue*18.5}px`;
  }
}

window.onload=()=>{
  render();
  renderScoreBoard(scores.red,scores.blue);
  document.querySelectorAll(".pull-button").forEach((element)=>{
    element.onclick=()=>{pull(element.classList[0])};
  });
}

let checkPoint=()=>{
  if(advantage.red===5 && scores.red<4){
    scores.red++;  
    renderScoreBoard(scores.red,scores.blue);
    cover();
    document.querySelector(".red-checkpoint .color").style.width="100%";
    advantage={red:0,blue:0}
    setTimeout(()=>{
      player.style.top="40.5px";
      countDown();
      document.querySelector(".red-checkpoint .color").style.width="0";
    },1000);
  }else if(advantage.blue===5 & scores.blue<4){
    scores.blue++;  
    renderScoreBoard(scores.red,scores.blue);
    cover();
    document.querySelector(".blue-checkpoint .color").style.width="100%"
    advantage={red:0,blue:0}
    setTimeout(()=>{
      player.style.top="40.5px";
      countDown();
      document.querySelector(".blue-checkpoint .color").style.width="0"
    },1000);
  }else if(advantage.red===5 && scores.red===4){
    scores.red++;
    renderScoreBoard(scores.red,scores.blue);
    document.querySelector(".red-checkpoint .color").style.width="100%";
    gameOverScreen("red");
  }else if(advantage.blue===5 && scores.blue===4){
    scores.blue++;
    renderScoreBoard(scores.red,scores.blue);
    document.querySelector(".blue-checkpoint .color").style.width="100%";
   gameOverScreen("blue");
   
  }
}
const pull=(player)=>{
  if(player=="red"){
    if(advantage.red>0){
      advantage.red++;
    }else if(advantage.red==0){
      if(advantage.blue>0){
        advantage.blue--;
      }else{
        advantage.red++;
      }
    }
  }else{
    if(advantage.blue>0){
      advantage.blue++;
    }else if(advantage.blue==0){
      if(advantage.red>0){
        advantage.red--;
      }else{
        advantage.blue++;
      }
    }
  }
  render();
  checkPoint();
}