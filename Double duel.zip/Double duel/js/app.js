window.onload=()=>{
  setTimeout(()=>{
    document.querySelector(".splash-screen").classList.add("splash");
    setTimeout(()=>{
      document.querySelector(".splash-screen").style.opacity=0;
      document.querySelector(".splash-screen").style.display='none';  
    },1001);
  },1000);
  
}